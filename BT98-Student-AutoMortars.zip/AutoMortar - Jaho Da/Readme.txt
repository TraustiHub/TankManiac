Sockets positions:

Attaching Head to Body:

x=0
y=0
z=181

Attaching Barrel to Head:

x= -102
y=0
z= 33